# Lab 03
## What this project does

- Using POST to build the login form.
- Verifies all required data on the server.
- Confirms the login credentials and username in PHP.
- Uses PHP session to track the login.
- Protect a page that only logged-in users can access.
- Logs out by clearing and destroying the session.

## How to test
- Open the base URL and confirm it redirect to the login page.
- Submit the form empty and confirm required field errors appear.
- Submit wrong credentials and confirm an valid login message appears.
- Submit the correct credentials and confirm you are redirect to the dashboard.

## Demo credentials

Username: **student**
Password: **Lab03!**

## Reflection

Through this lab, I gained practical knowledge of how PHP login system operates. I observed how the server verifies the form, displays problems, and grants access only when the user is logged in. I also discovered that the session are used to keep the user logged in between pages and that PHP pages need to run through a server(XAAMP).
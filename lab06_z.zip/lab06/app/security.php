<?php
declare(strict_types=1);
// Escape output for HTML (XSS prevention)
function e(string $value): string {
 return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
}
// Basic input cleaning (sanitize). Still validate rules in each form!
function clean_string(string $value): string {
 return trim($value);
}
function security_headers(): void {
 header("X-Content-Type-Options: nosniff");
 header("X-Frame-Options: DENY");
 header("Referrer-Policy: no-referrer");
 // Very simple CSP for this lab (blocks external JS by default)
 header("Content-Security-Policy: default-src 'self'");
} 
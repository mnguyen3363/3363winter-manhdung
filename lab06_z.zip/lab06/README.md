# Lab 06 — PHP Web Security & Sessions (Secure Notes)
**Student Name:**Manh Dung Nguyen 
**Date:**2026/02/15
## 1 What I built (1–2 sentences)
In this lab, I built a PHP web application with a secure login, access control and sessions.Managing private notes that features a user authentication system with different access levels (user and admin)
## 2How to run my lab
**Database name:** `lab06_manhdung'
**Start page URL:**http://localhost/3363winter/lab06/public/index.php
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name
5. Open the start page URL above
## 3 Security features checklist:
 - password_hash() and password_verify()
 - prepared statements
 - Escaping output (XSS prevention)
 - Access control (role-based)
 - Session timeout
 - Session fixation prevention 
 - Security headers

## 4 Test Results (PASS/FAIL)
- Register works: PASS
- Login works (correct password): PASS
- Login fails (wrong password): PASS
- Dashboard redirects when logged out: PASS
- Create note works: PASS
- XSS test does NOT run (`<script>alert('xss')</script>`): PASS
- Admin page (user gets 403): PASS
- Admin page (admin can view): PASS
- Session timeout works: PASS
## 5 Reflection: what I have learned from Lab 06 (3-5 sentences)
This lab taught me how crucial it is to never save passwords in plain text and how PHP's built-in scrambling functions offer a reliable solution.I obtained practical experience protecting against the most prevalent online dangers, like escaping output to eliminate XSS threats and blocking SQL injection with prepared statements.Finally, I learned how to implement a session timeout and role-based access control to ensure that sensitive data and administrative features remain protected
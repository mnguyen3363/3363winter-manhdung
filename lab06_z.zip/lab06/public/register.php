<?php
declare(strict_types=1);
require_once __DIR__ . "/../app/security.php";
require_once __DIR__ . "/../app/db.php";
security_headers();
$errors = [];
$success = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
 $email = clean_string($_POST["email"] ?? "");
 $password = $_POST["password"] ?? "";
 // Validate email format
 if ($email === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
 $errors[] = "Please enter a valid email.";
 }
 // Enforce password rule (min 8 chars)
 if (strlen($password) < 8) {
 $errors[] = "Password must be at least 8 characters.";
 }
 if (!$errors) {
 // Hash password securely
 $hash = password_hash($password, PASSWORD_DEFAULT);
 // Insert user using prepared statement
 // Optional: set first registered user as admin for testing.
 try {
 $stmt = $pdo->prepare("INSERT INTO users (email, password_hash, role) VALUES
(?, ?, 'user')");
 $stmt->execute([$email, $hash]);
 $success = "Registration successful. You can now login.";
 } catch (PDOException $e) {
 $errors[] = "That email is already registered.";
 }
 }
}
?>
<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Register</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
 <h1>Register</h1>
 <?php if ($success): ?>
 <p><?= e($success) ?></p>
 <?php endif; ?>
 <?php if ($errors): ?>
 <ul>
 <?php foreach ($errors as $err): ?>
 <li><?= e($err) ?></li>
 <?php endforeach; ?>
 </ul>
 <?php endif; ?>
 <form method="post" novalidate>
 <label>Email:
 <input type="email" name="email" required>
 </label>
 <br><br>
 <label>Password:
 <input type="password" name="password" minlength="8" required>
 </label>
 <br><br>
 <button type="submit">Create Account</button>
 </form>
 <!-- STUDENT TODO (JS): Add a small client-side check for password length before
submit. -->
 <p><a href="login.php">Go to Login</a></p>
 </div>
</body>
</html>
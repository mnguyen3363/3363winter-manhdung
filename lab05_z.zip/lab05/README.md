# Lab 05 - PHP + MySQL CRUD (PDO)
## Student Info
- Name: Manh Dung Nguyen
- Course: Advanced Web Design & Development
- Lab: 05
## Database
- Database name: lab05_manhdung
- Table: students
### Schema (SQL)
```sql
CREATE TABLE students (
 student_id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(100) NOT NULL,
 email VARCHAR(120) NOT NULL UNIQUE,
 program VARCHAR(80) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
## How to Run (Local)
1. Start XAMPP: Apache + MySQL
2. Put project here:
 - C:\xampp\htdocs\winter3363\lab05\
3. Open:
 - http://localhost/3363winter/lab05/public/
 ## Features Completed
- [ ] PDO connection (db.php)
- [ ] READ (index.php)
- [ ] CREATE (create.php)
- [ ] UPDATE (edit.php)
- [ ] DELETE (delete.php)
- [ ] Prepared statements used everywhere
- [ ] Output escaped with htmlspecialchars
## Screenshots (Required)
Submit required screenshots in a file to Moodle.
## Notes / Challenges
After practicing lab05, I have learned how to work with multiple files and add this seperate files works perfectly together. I was confused at the begining of the lab during created the PHP files inside 3 seperate folders but I figure out the way to fix the problem rapidly which can follow up with the flow of my instructor. The most important thing I have learned from this lab which helped me to check the mistake that i made was checking all the code before checking the link in the browser. 
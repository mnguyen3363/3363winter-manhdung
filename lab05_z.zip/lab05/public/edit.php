<?php
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/functions.php";
$errors = [];
$id = get_int_or_null($_GET["id"] ?? null);
if (!$id) {
 redirect("index.php?msg=error");
}
// Load existing student
$sql = "SELECT student_id, full_name, email, program
 FROM students
 WHERE student_id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([":id" => $id]);
$student = $stmt->fetch();
if (!$student) {
 redirect("index.php?msg=error");
}
$full_name = $student["full_name"];
$email = $student["email"];
$program = $student["program"];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
 $full_name = trim($_POST["full_name"] ?? "");
 $email = trim($_POST["email"] ?? "");
 $program = trim($_POST["program"] ?? "");
 // Validation
 if ($full_name === "") $errors[] = "Full name is required.";
 if ($email === "") $errors[] = "Email is require.";
 if ($email !== "" && !is_valid_email($email)) $errors[] = "Email format is invalid.";
 if ($program === "") $errors[] = "Program is required.";
 if (!$errors) {
 try {
 $sql = "UPDATE students
 SET full_name = :full_name,
 email = :email,
 program = :program
 WHERE student_id = :id";
 $stmt = $pdo->prepare($sql);
 $stmt->execute([
 ":full_name" => $full_name,
 ":email" => $email,
 ":program" => $program,
 ":id" => $id
 ]);
 redirect("index.php?msg=updated");
 } catch (PDOException $e) {
 $errors[] = "Database error: " . $e->getMessage();
 }
 }
}
?>
<?php require_once __DIR__ . "/../includes/header.php"; ?>
<h2>Edit Student (ID: <?= (int)$id ?>)</h2>
<?php if ($errors): ?>
 <div class="error">
 <strong>Please fix the following:</strong>
 <ul>
 <?php foreach ($errors as $err): ?>
 <li><?= e($err) ?></li>
 <?php endforeach; ?>
 </ul>
 </div>
<?php endif; ?>
<form method="post" action="edit.php?id=<?= (int)$id ?>" novalidate>
 <label>Full Name</label>
 <input type="text" name="full_name" value="<?= e($full_name) ?>" />
 <label>Email</label>
 <input type="email" name="email" value="<?= e($email) ?>" />
 <label>Program</label>
 <input type="text" name="program" value="<?= e($program) ?>" />
 <div class="form-actions">
 <button class="btn" type="submit">Save Changes</button>
 <a class="btn" href="index.php">Cancel</a>
 </div>
</form>
<?php require_once __DIR__ . "/../includes/footer.php"; ?>

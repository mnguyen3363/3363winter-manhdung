<?php
session_start();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
$success = $_SESSION['success'] ?? '';
unset($_SESSION['errors'], $_SESSION['old'], $_SESSION['success']);
require_once __DIR__ . "/includes/helpers.php";
// Helper to read old values safely
function old(string $key, array $old): string {
 return isset($old[$key]) ? e((string)$old[$key]) : "";
}
// Helper to show error
function err(string $key, array $errors): string {
 return isset($errors[$key]) ? e((string)$errors[$key]) : "";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1"/>
 <title>Lab 07 - Validation</title>
 <link rel="stylesheet" href="assets/style.css">
 <!--<script src="assets/validation.js" defer></script>-->
</head>
<body>
 <main class="container">
 <h1>Student Feedback Form</h1>
 <?php if ($success): ?>
 <div class="msg success"><?= e($success) ?></div>
 <?php endif; ?>
 <?php if (!empty($errors)): ?>
 <div class="msg error">Please fix the errors below and submit
again.</div>
 <?php endif; ?>
 <form id="feedbackForm" method="POST" action="process.php" novalidate>
 <div class="field">
 <label for="name">Name *</label>
 <input id="name" name="name" type="text" value="<?= old('name',$old) ?>" />
 <div class="hint">2–50 chars. Letters/spaces/hyphen only.</div>
 <div class="err" data-err-for="name"><?= err('name', $errors)
?></div>
 </div>
 <div class="field">
 <label for="email">Email *</label>
 <input id="email" name="email" type="email" value="<?= old('email',
$old) ?>" />
 <div class="err" data-err-for="email"><?= err('email', $errors)
?></div>
 </div>
 <div class="field">
 <label for="course">Course Code *</label>
 <input id="course" name="course" type="text" placeholder="INTE3363"
value="<?= old('course', $old) ?>" />
 <div class="hint">Format: INTE + 4 digits (e.g., INTE3363)</div>
 <div class="err" data-err-for="course"><?= err('course', $errors)
?></div>
 </div>
 <div class="field">
 <label for="rating">Rating (1–5) *</label>
 <input id="rating" name="rating" type="number" min="1" max="5"
value="<?= old('rating', $old) ?>" />
 <div class="err" data-err-for="rating"><?= err('rating', $errors)
?></div>
 </div>
 <div class="field">
 <label for="comments">Comments (optional)</label>
 <textarea id="comments" name="comments" rows="4"><?=
old('comments', $old) ?></textarea>
 <div class="hint">If provided: at least 10 characters. Max
500.</div>
 <div class="err" data-err-for="comments"><?= err('comments',
$errors) ?></div>
 </div>
 <div class="field checkbox">
 <?php $checked = !empty($old['agree']) ? 'checked' : ''; ?>
 <label>
 <input id="agree" name="agree" type="checkbox" value="1" <?=
$checked ?> />
 I agree to the terms *
 </label>
 <div class="err" data-err-for="agree"><?= err('agree', $errors)
?></div>
 </div> 
 <button type="submit">Submit</button>
 </form>
 </main>
</body>
</html>
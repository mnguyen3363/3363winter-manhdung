# Lab 07 — Validation & Error Handling (JavaScript + PHP)
**Student Name:** Manh Dung Nguyen
**Submission Date:** Feb 28th, 2026
## 1 How to Run
1. Start **Apache** in XAMPP.
2. Put this folder in: `C:\xampp\htdocs\3363winter\lab07\`
3. Testing URL: http://localhost/3363winter/lab07/index.php
                http://localhost/3363winter/lab07/view_submissions.php 
---
## 2 Files Included (check)
- [✅] `index.php`
- [✅] `process.php`
- [✅] `includes/helpers.php`
- [✅] `assets/validation.js`
- [✅] `assets/style.css`
- [✅] `data/submissions.jsonl`
- [✅] `logs/errors.log`
---
## 3 Validation Completed (check)
### JavaScript (client-side)
- [✅] Required fields blocked
- [✅] Email format checked
- [✅] Course code format checked (INTE####)
- [✅] Rating checked (1–5)
- [✅] Agree checkbox required
- [✅] Errors show beside fields
- [✅] Prevent submit when invalid
### PHP (server-side)
- [✅] Validates the same rules again
- [✅] Shows errors beside fields
- [✅] Keeps sticky values (old input stays)
- [✅] Uses `try/catch` for saving file
- [✅] Logs errors to `logs/errors.log`
---
## 4 Testing Checklist (Required)
Fill in Pass/Fail.
| Test | Pass/Fail |
|------|----------|
| Empty submit shows errors | PASS|
| Invalid email blocked | PASS |
| Invalid course code blocked | PASS |
| Rating out of range blocked | PASS |
| Agree unchecked blocked | PASS |
| Disable JS (comment out script tag) → PHP still blocks invalid data | PASS|
| Valid submit saves to `submissions.jsonl` | PASS |
---
## 5 Compare JavaScript vs PHP Validation (What I learned)
Fill in 1–2 sentences for each.
**JavaScript validation is good for:**
Improving user experience and cutting down on pointless server requests by quickly verifying user input in the browser before the form is submitted.
**JavaScript validation is NOT reliable for security because:**
It runs on the client side and can be disabled or bypassed by users, allowing malicious data to still be sent to the server
**PHP validation is important because:**
It runs on the server side and securely checks user input after submission, preventing invalid or malicious data from being processed.
**One example from my testing (disable JS) that proved PHP is needed because:**
When JavaScript was disabled, the form still submitted invalid input, showing that only PHP validation could properly stop incorrect or unsafe data on the server.